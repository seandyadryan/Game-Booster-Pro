# Current Localized Store Text

Interface and shared images: English. Titles and descriptions: localized below.

~~~text
<en-US>
Title: Game Tools: Network & Cache

Short description: Check TCP latency, clear this app's cache, and launch your games.

Full description:
Game Tools is an Android utility for TCP network latency, this app's cache, game shortcuts and display information.

Network Latency runs five TCP connections to Cloudflare 1.1.1.1:443 and shows average, minimum and maximum latency, jitter and failed probes. These are connection timings, not game-server ping or an Internet speed test.

This app's cache clears only Game Tools' temporary cache and reports before, removed and remaining bytes. Other apps' caches are cleared manually in Android settings. Top-five cache ranking requires Usage Access and Android 8 or later.

Launch installed apps identified as games, open Android display settings and view battery status. Display refresh rate is measured in Hz, not game FPS. In-game graphics remain controlled by the game.

Optional Do Not Disturb can silence alarms and media but does not reject calls. An optional display refresh-rate bar requires Usage Access and Display over other apps permission.

Results are processed on your device. User-requested network checks contact Cloudflare, which can receive your public IP address. No advertising or analytics SDK is included. The app interface is in English. Features depend on your device, Android version and permissions.

Open game library opens the game list without cleaning caches or changing device settings. App settings only opens Android settings. This app does not close recent apps, stop other apps, change game graphics, measure game FPS or increase game performance.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</en-US>
~~~

~~~text
<id>
Title: Game Tools: Jaringan & Cache

Short description: Periksa latensi TCP, bersihkan cache aplikasi ini, dan buka game.

Full description:
Game Tools adalah utilitas Android untuk latensi jaringan TCP, cache aplikasi ini, pintasan game, dan informasi layar.

Network Latency menjalankan lima koneksi TCP ke Cloudflare 1.1.1.1:443 dan menampilkan latensi rata-rata, minimum, maksimum, jitter, serta probe gagal. Hasilnya adalah waktu koneksi, bukan ping server game atau uji kecepatan internet.

This app's cache hanya membersihkan cache sementara Game Tools dan menampilkan byte sebelum, dibersihkan, serta tersisa. Cache aplikasi lain dibersihkan secara manual melalui pengaturan Android. Peringkat lima cache terbesar memerlukan Usage Access dan Android 8 atau lebih baru.

Buka aplikasi terpasang yang dikenali sebagai game, pengaturan layar Android, dan informasi baterai. Refresh rate layar ditampilkan dalam Hz, bukan FPS game. Grafis di dalam game tetap diatur oleh game tersebut.

Do Not Disturb bersifat opsional dan dapat membisukan alarm serta media, tetapi tidak menolak panggilan. Bar refresh rate opsional memerlukan Usage Access dan izin tampil di atas aplikasi lain.

Hasil diproses di perangkat Anda. Pemeriksaan jaringan yang Anda jalankan menghubungi Cloudflare, yang dapat menerima alamat IP publik Anda. Tidak ada SDK iklan atau analitik. Antarmuka aplikasi berbahasa Inggris. Fitur bergantung pada perangkat, versi Android, dan izin.

Open game library membuka daftar game tanpa membersihkan cache atau mengubah pengaturan perangkat. App settings hanya membuka pengaturan Android. Aplikasi ini tidak menutup Recent Apps, menghentikan aplikasi lain, mengubah grafis game, mengukur FPS game, atau meningkatkan performa game.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</id>
~~~

~~~text
<ar>
Title: Game Tools: الشبكة والذاكرة

Short description: افحص زمن استجابة TCP ونظّف ذاكرة هذا التطبيق وشغّل ألعابك.

Full description:
Game Tools أداة Android لفحص زمن استجابة شبكة TCP وذاكرة التخزين المؤقت لهذا التطبيق واختصارات الألعاب ومعلومات الشاشة.

يجري Network Latency خمس اتصالات TCP مع Cloudflare على 1.1.1.1:443، ويعرض متوسط زمن الاستجابة وأدنى وأعلى قيمة والتذبذب والمحاولات الفاشلة. النتائج تقيس وقت الاتصال، وليست قياسًا لزمن استجابة خادم اللعبة أو سرعة الإنترنت.

يمسح This app's cache ذاكرة Game Tools المؤقتة فقط، ويعرض الحجم قبل التنظيف والمحذوف والمتبقي. تُنظَّف ذاكرة التطبيقات الأخرى يدويًا من إعدادات Android. ترتيب أكبر خمس ذاكرات مؤقتة يتطلب إذن الوصول إلى بيانات الاستخدام وAndroid 8 أو أحدث.

شغّل التطبيقات المثبتة التي يتعرف عليها النظام كألعاب وافتح إعدادات الشاشة واعرض حالة البطارية. معدل تحديث الشاشة يُقاس بوحدة Hz وليس FPS اللعبة. تظل رسومات اللعبة خاضعة لإعداداتها.

يمكن لوضع عدم الإزعاج الاختياري إسكات المنبهات والوسائط، لكنه لا يرفض المكالمات. شريط معدل التحديث الاختياري يتطلب الوصول إلى بيانات الاستخدام وإذن الظهور فوق التطبيقات.

تُعالج النتائج على جهازك. تتصل فحوص الشبكة التي تطلبها بخدمة Cloudflare التي قد تتلقى عنوان IP العام. لا توجد حزم SDK للإعلانات أو التحليلات. واجهة التطبيق بالإنجليزية. تعتمد الميزات على الجهاز وإصدار Android والأذونات.

يفتح Open game library قائمة الألعاب دون تنظيف ذاكرة التخزين المؤقت أو تغيير إعدادات الجهاز. يفتح App settings إعدادات Android فقط. لا يغلق التطبيق التطبيقات الحديثة ولا يوقف التطبيقات الأخرى ولا يغير رسومات الألعاب ولا يقيس FPS للألعاب ولا يزيد أداءها.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</ar>
~~~

~~~text
<cs-CZ>
Title: Game Tools: Síť a mezipaměť

Short description: Změřte latenci TCP, vyčistěte mezipaměť této aplikace a spusťte hry.

Full description:
Game Tools je nástroj pro Android pro měření latence TCP, mezipaměť této aplikace, herní zkratky a informace o displeji.

Network Latency provede pět připojení TCP ke Cloudflare 1.1.1.1:443 a zobrazí průměrnou, minimální a maximální latenci, kolísání a neúspěšné pokusy. Jde o dobu připojení, nikoli ping herního serveru nebo test rychlosti internetu.

This app's cache vymaže pouze dočasnou mezipaměť Game Tools a zobrazí původní, odstraněné a zbývající bajty. Mezipaměť jiných aplikací se maže ručně v nastavení Androidu. Žebříček pěti největších mezipamětí vyžaduje přístup k údajům o používání a Android 8 nebo novější.

Spouštějte nainstalované aplikace rozpoznané jako hry, otevřete nastavení displeje a zobrazte stav baterie. Obnovovací frekvence displeje je v Hz, nikoli FPS hry. Grafiku uvnitř hry nastavuje samotná hra.

Volitelný režim Nerušit může ztišit budíky a média, ale neodmítá hovory. Volitelný panel obnovovací frekvence vyžaduje přístup k údajům o používání a oprávnění zobrazovat přes jiné aplikace.

Výsledky se zpracovávají ve vašem zařízení. Síťové kontroly na váš pokyn kontaktují Cloudflare, který může získat vaši veřejnou IP adresu. Aplikace neobsahuje reklamní ani analytické SDK. Rozhraní je v angličtině. Funkce závisí na zařízení, verzi Androidu a oprávněních.

Open game library otevře seznam her bez čištění mezipaměti nebo změn nastavení zařízení. App settings pouze otevře nastavení Androidu. Aplikace nezavírá nedávné aplikace, neukončuje jiné aplikace, nemění grafiku her, neměří herní FPS ani nezvyšuje herní výkon.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</cs-CZ>
~~~

~~~text
<da-DK>
Title: Game Tools: Netværk og cache

Short description: Mål TCP-latens, ryd denne apps cache, og start dine spil.

Full description:
Game Tools er et Android-værktøj til TCP-netværkslatens, denne apps cache, spilgenveje og skærmoplysninger.

Network Latency opretter fem TCP-forbindelser til Cloudflare 1.1.1.1:443 og viser gennemsnitlig, laveste og højeste latens, jitter og mislykkede forsøg. Det er forbindelsestider, ikke ping til spilservere eller en internethastighedstest.

This app's cache rydder kun Game Tools' midlertidige cache og viser antal byte før, fjernet og tilbage. Andre apps' cache ryddes manuelt i Android-indstillingerne. Listen over de fem største cacher kræver adgang til brugsdata og Android 8 eller nyere.

Start installerede apps, der genkendes som spil, åbn Androids skærmindstillinger, og se batteristatus. Skærmens opdateringsfrekvens måles i Hz, ikke spillets FPS. Spillet styrer selv sin grafik.

Valgfri Forstyr ikke kan slå alarmer og medier fra, men afviser ikke opkald. Den valgfrie opdateringsbjælke kræver adgang til brugsdata og tilladelse til at vise over andre apps.

Resultater behandles på din enhed. Netværkskontroller, du starter, kontakter Cloudflare, som kan modtage din offentlige IP-adresse. Ingen annonce- eller analyse-SDK er inkluderet. Appens brugerflade er på engelsk. Funktioner afhænger af enhed, Android-version og tilladelser.

Open game library åbner spillisten uden at rydde cache eller ændre enhedens indstillinger. App settings åbner kun Android-indstillinger. Appen lukker ikke seneste apps, stopper ikke andre apps, ændrer ikke spilgrafik, måler ikke spil-FPS og øger ikke spilydelsen.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</da-DK>
~~~

~~~text
<de-DE>
Title: Game Tools: Netzwerk & Cache

Short description: TCP-Latenz prüfen, den Cache dieser App leeren und Spiele starten.

Full description:
Game Tools ist ein Android-Werkzeug für TCP-Netzwerklatenz, den Cache dieser App, Spielverknüpfungen und Displayinformationen.

Network Latency stellt fünf TCP-Verbindungen zu Cloudflare 1.1.1.1:443 her und zeigt durchschnittliche, minimale und maximale Latenz, Jitter sowie fehlgeschlagene Versuche. Gemessen werden Verbindungszeiten, kein Spielserver-Ping und keine Internetgeschwindigkeit.

This app's cache leert nur den temporären Cache von Game Tools und zeigt die vorherigen, entfernten und verbleibenden Bytes. Caches anderer Apps werden manuell in den Android-Einstellungen geleert. Die Rangliste der fünf größten Caches benötigt Nutzungsdatenzugriff und Android 8 oder neuer.

Starten Sie installierte Apps, die als Spiele erkannt werden, öffnen Sie die Android-Displayeinstellungen und sehen Sie den Akkustatus. Die Bildwiederholrate des Displays wird in Hz gemessen, nicht als Spiel-FPS. Die Grafik im Spiel steuert das jeweilige Spiel.

Der optionale Nicht-stören-Modus kann Wecker und Medien stummschalten, weist aber keine Anrufe ab. Die optionale Anzeigeleiste der Bildwiederholrate benötigt Nutzungsdatenzugriff und die Berechtigung, über anderen Apps zu erscheinen.

Ergebnisse werden auf Ihrem Gerät verarbeitet. Von Ihnen gestartete Netzwerkprüfungen kontaktieren Cloudflare, das Ihre öffentliche IP-Adresse erhalten kann. Keine Werbe- oder Analyse-SDKs. Die App-Oberfläche ist auf Englisch. Funktionen hängen von Gerät, Android-Version und Berechtigungen ab.

Open game library öffnet die Spieleliste, ohne Caches zu leeren oder Geräteeinstellungen zu ändern. App settings öffnet nur die Android-Einstellungen. Die App schließt keine zuletzt verwendeten Apps, beendet keine anderen Apps, verändert keine Spielgrafiken, misst keine Spiel-FPS und steigert nicht die Spielleistung.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</de-DE>
~~~

~~~text
<es-419>
Title: Game Tools: Red y caché

Short description: Consulta la latencia TCP, limpia la caché de esta app y abre tus juegos.

Full description:
Game Tools es una utilidad Android para latencia TCP, caché de esta app, accesos a juegos e información de pantalla.

Network Latency realiza cinco conexiones TCP a Cloudflare 1.1.1.1:443 y muestra latencia promedio, mínima y máxima, jitter e intentos fallidos. Son tiempos de conexión, no el ping del servidor del juego ni una prueba de velocidad de Internet.

This app's cache limpia únicamente la caché temporal de Game Tools y muestra los bytes iniciales, eliminados y restantes. La caché de otras apps se limpia manualmente en los ajustes de Android. La lista de las cinco cachés más grandes requiere Acceso de uso y Android 8 o posterior.

Abre apps instaladas identificadas como juegos, accede a los ajustes de pantalla de Android y consulta la batería. La frecuencia de actualización de la pantalla se mide en Hz, no en FPS del juego. Cada juego controla sus propios gráficos.

No molestar es opcional y puede silenciar alarmas y contenido multimedia, pero no rechaza llamadas. La barra opcional de frecuencia de actualización requiere Acceso de uso y permiso para mostrarse sobre otras apps.

Los resultados se procesan en tu dispositivo. Las pruebas de red que solicitas contactan a Cloudflare, que puede recibir tu IP pública. No se incluyen SDK de publicidad ni análisis. La interfaz está en inglés. Las funciones dependen del dispositivo, la versión de Android y los permisos.

Open game library abre la lista de juegos sin limpiar cachés ni cambiar ajustes del dispositivo. App settings solo abre los ajustes de Android. Esta app no cierra apps recientes, no detiene otras apps, no cambia gráficos, no mide FPS de juegos ni aumenta su rendimiento.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</es-419>
~~~

~~~text
<es-ES>
Title: Game Tools: Red y caché

Short description: Consulta la latencia TCP, limpia la caché de esta app y abre tus juegos.

Full description:
Game Tools es una utilidad Android para latencia TCP, caché de esta aplicación, accesos a juegos e información de pantalla.

Network Latency realiza cinco conexiones TCP a Cloudflare 1.1.1.1:443 y muestra latencia media, mínima y máxima, jitter e intentos fallidos. Son tiempos de conexión, no el ping del servidor del juego ni una prueba de velocidad de Internet.

This app's cache limpia únicamente la caché temporal de Game Tools y muestra los bytes iniciales, eliminados y restantes. La caché de otras aplicaciones se limpia manualmente en los ajustes de Android. La lista de las cinco cachés más grandes requiere Acceso de uso y Android 8 o posterior.

Abre aplicaciones instaladas identificadas como juegos, accede a los ajustes de pantalla de Android y consulta la batería. La frecuencia de actualización de la pantalla se mide en Hz, no en FPS del juego. Cada juego controla sus propios gráficos.

No molestar es opcional y puede silenciar alarmas y contenido multimedia, pero no rechaza llamadas. La barra opcional de frecuencia de actualización requiere Acceso de uso y permiso para mostrarse sobre otras aplicaciones.

Los resultados se procesan en tu dispositivo. Las pruebas de red que solicitas contactan con Cloudflare, que puede recibir tu IP pública. No se incluyen SDK de publicidad ni análisis. La interfaz está en inglés. Las funciones dependen del dispositivo, la versión de Android y los permisos.

Open game library abre la lista de juegos sin limpiar cachés ni cambiar ajustes del dispositivo. App settings solo abre los ajustes de Android. Esta aplicación no cierra aplicaciones recientes, no detiene otras aplicaciones, no cambia gráficos, no mide FPS de juegos ni aumenta su rendimiento.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</es-ES>
~~~

~~~text
<fi-FI>
Title: Game Tools: Verkkotyökalut

Short description: Mittaa TCP-viive, tyhjennä tämän sovelluksen välimuisti ja avaa pelejä.

Full description:
Game Tools on Android-työkalu TCP-verkkoviiveelle, tämän sovelluksen välimuistille, pelien pikakuvakkeille ja näytön tiedoille.

Network Latency muodostaa viisi TCP-yhteyttä Cloudflareen osoitteessa 1.1.1.1:443. Näet keskimääräisen, pienimmän ja suurimman viiveen, viiveen vaihtelun ja epäonnistuneet yritykset. Tulokset ovat yhteyden muodostusaikoja, eivät pelipalvelimen ping-arvoja tai internetin nopeustesti.

This app's cache tyhjentää vain Game Toolsin tilapäisen välimuistin ja näyttää tavut ennen tyhjennystä, poistetut tavut ja jäljellä olevan määrän. Muiden sovellusten välimuisti tyhjennetään käsin Androidin asetuksissa. Viiden suurimman välimuistin lista vaatii käyttötietojen käyttöoikeuden ja Android 8:n tai uudemman.

Avaa peleiksi tunnistettuja sovelluksia, Androidin näyttöasetukset ja akun tiedot. Näytön virkistystaajuus mitataan hertseinä, ei pelin FPS:nä. Pelin grafiikka asetetaan itse pelissä.

Valinnainen Älä häiritse voi mykistää herätykset ja median, mutta ei hylkää puheluja. Valinnainen virkistystaajuuspalkki vaatii käyttötietojen ja muiden sovellusten päällä näyttämisen oikeudet.

Tulokset käsitellään laitteessasi. Käynnistämäsi verkkotarkistus ottaa yhteyden Cloudflareen, joka voi saada julkisen IP-osoitteesi. Ei mainos- tai analytiikka-SDK:ita. Käyttöliittymä on englanniksi. Toiminnot riippuvat laitteesta, Android-versiosta ja käyttöoikeuksista.

Open game library avaa peliluettelon tyhjentämättä välimuisteja tai muuttamatta laitteen asetuksia. App settings avaa vain Android-asetukset. Sovellus ei sulje viimeaikaisia sovelluksia, pysäytä muita sovelluksia, muuta pelien grafiikkaa, mittaa pelien FPS-lukemaa tai paranna pelien suorituskykyä.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</fi-FI>
~~~

~~~text
<fr-FR>
Title: Game Tools: Réseau et cache

Short description: Mesurez la latence TCP, videz le cache de cette app et lancez vos jeux.

Full description:
Game Tools est un utilitaire Android pour la latence TCP, le cache de cette application, les raccourcis de jeux et les informations d'écran.

Network Latency effectue cinq connexions TCP vers Cloudflare 1.1.1.1:443 et affiche la latence moyenne, minimale et maximale, la gigue et les tentatives échouées. Il s'agit de temps de connexion, pas du ping d'un serveur de jeu ni d'un test de débit Internet.

This app's cache vide uniquement le cache temporaire de Game Tools et affiche les octets avant nettoyage, supprimés et restants. Le cache des autres applications se vide manuellement dans les paramètres Android. Le classement des cinq plus grands caches nécessite l'accès aux données d'utilisation et Android 8 ou plus récent.

Lancez les applications reconnues comme jeux, ouvrez les paramètres d'affichage Android et consultez la batterie. Le taux de rafraîchissement de l'écran est mesuré en Hz, pas en FPS du jeu. Chaque jeu contrôle ses propres graphismes.

Le mode Ne pas déranger est facultatif. Il peut couper les alarmes et les médias, mais ne rejette pas les appels. La barre facultative de rafraîchissement nécessite l'accès aux données d'utilisation et l'autorisation d'affichage par-dessus les applications.

Les résultats sont traités sur votre appareil. Les vérifications réseau demandées contactent Cloudflare, qui peut recevoir votre adresse IP publique. Aucun SDK publicitaire ou analytique. L'interface est en anglais. Les fonctions dépendent de l'appareil, d'Android et des autorisations.

Open game library ouvre la liste des jeux sans vider les caches ni modifier les paramètres de l'appareil. App settings ouvre uniquement les paramètres Android. L'application ne ferme pas les applications récentes, n'arrête pas les autres applications, ne modifie pas les graphismes, ne mesure pas les FPS des jeux et n'améliore pas leurs performances.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</fr-FR>
~~~

~~~text
<hi-IN>
Title: Game Tools: नेटवर्क और कैश

Short description: TCP लेटेंसी जाँचें, इस ऐप का कैश साफ करें और अपने गेम खोलें।

Full description:
Game Tools TCP नेटवर्क लेटेंसी, इस ऐप के कैश, गेम शॉर्टकट और डिस्प्ले की जानकारी के लिए एक Android टूल है।

Network Latency, Cloudflare 1.1.1.1:443 से पाँच TCP कनेक्शन बनाकर औसत, न्यूनतम और अधिकतम लेटेंसी, जिटर और असफल प्रयास दिखाता है। ये कनेक्शन का समय है, गेम सर्वर का पिंग या इंटरनेट स्पीड टेस्ट नहीं।

This app's cache केवल Game Tools का अस्थायी कैश साफ करता है और पहले के, हटाए गए और बाकी बाइट दिखाता है। दूसरे ऐप का कैश Android सेटिंग में मैन्युअल रूप से साफ किया जाता है। पाँच सबसे बड़े कैश की सूची के लिए उपयोग संबंधी एक्सेस और Android 8 या नया संस्करण चाहिए।

गेम के रूप में पहचाने गए इंस्टॉल किए गए ऐप खोलें, Android डिस्प्ले सेटिंग खोलें और बैटरी की स्थिति देखें। स्क्रीन की रिफ्रेश दर Hz में होती है, गेम के FPS में नहीं। गेम के ग्राफिक्स उसी गेम की सेटिंग से नियंत्रित होते हैं।

वैकल्पिक परेशान न करें मोड अलार्म और मीडिया को म्यूट कर सकता है, लेकिन कॉल अस्वीकार नहीं करता। वैकल्पिक रिफ्रेश दर बार के लिए उपयोग संबंधी एक्सेस और अन्य ऐप पर दिखाने की अनुमति चाहिए।

नतीजे आपके डिवाइस पर प्रोसेस होते हैं। आपके अनुरोध पर नेटवर्क जाँच Cloudflare से संपर्क करती है, जिसे आपका सार्वजनिक IP पता मिल सकता है। विज्ञापन या एनालिटिक्स SDK शामिल नहीं है। इंटरफेस अंग्रेज़ी में है। सुविधाएँ डिवाइस, Android संस्करण और अनुमतियों पर निर्भर हैं।

Open game library कैश साफ किए या डिवाइस सेटिंग बदले बिना गेम की सूची खोलता है। App settings केवल Android सेटिंग खोलता है। यह ऐप हाल के ऐप बंद नहीं करता, अन्य ऐप रोकता नहीं है, गेम ग्राफिक्स नहीं बदलता, गेम FPS नहीं मापता और गेम का प्रदर्शन नहीं बढ़ाता।

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</hi-IN>
~~~

~~~text
<hu-HU>
Title: Game Tools: Hálózati eszközök

Short description: TCP-késleltetés mérése, az app gyorsítótárának törlése és játékindítás.

Full description:
A Game Tools Android-segédprogram TCP-késleltetéshez, az alkalmazás saját gyorsítótárához, játékparancsikonokhoz és kijelzőadatokhoz.

A Network Latency öt TCP-kapcsolatot létesít a Cloudflare 1.1.1.1:443 címével. Megjeleníti az átlagos, legkisebb és legnagyobb késleltetést, az ingadozást és a sikertelen próbákat. Ezek kapcsolódási idők, nem játékszerver-ping vagy internetsebesség-teszt.

A This app's cache csak a Game Tools ideiglenes gyorsítótárát törli, és mutatja az eredeti, törölt és megmaradt bájtokat. Más alkalmazások gyorsítótárát kézzel, az Android beállításaiban lehet törölni. Az öt legnagyobb gyorsítótár listájához használati hozzáférés és Android 8 vagy újabb kell.

Indítson játékként felismert alkalmazásokat, nyissa meg a kijelző beállításait és tekintse meg az akkumulátor állapotát. A kijelző képfrissítése Hz-ben látható, nem a játék FPS-e. A játék grafikáját maga a játék szabályozza.

Az opcionális Ne zavarjanak mód az ébresztéseket és a médiát is némíthatja, de nem utasítja el a hívásokat. A képfrissítési sávhoz használati hozzáférés és más alkalmazások feletti megjelenítési engedély kell.

Az eredmények az eszközön kerülnek feldolgozásra. A kért hálózati teszt kapcsolatba lép a Cloudflare-rel, amely megkaphatja a nyilvános IP-címét. Nincs hirdetési vagy analitikai SDK. A felület angol nyelvű. A funkciók az eszköztől, az Android-verziótól és az engedélyektől függenek.

Az Open game library a gyorsítótárak törlése és az eszközbeállítások módosítása nélkül nyitja meg a játéklistát. Az App settings csak az Android beállításait nyitja meg. Az app nem zárja be a legutóbbi alkalmazásokat, nem állít le más appokat, nem módosítja a játékok grafikáját, nem méri a játékok FPS-ét és nem növeli a teljesítményüket.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</hu-HU>
~~~

~~~text
<it-IT>
Title: Game Tools: Rete e cache

Short description: Misura la latenza TCP, svuota la cache di questa app e avvia i tuoi giochi.

Full description:
Game Tools è un'utilità Android per latenza TCP, cache di questa app, scorciatoie per giochi e informazioni sul display.

Network Latency effettua cinque connessioni TCP a Cloudflare 1.1.1.1:443 e mostra latenza media, minima e massima, jitter e tentativi non riusciti. Sono tempi di connessione, non il ping del server di gioco o un test della velocità Internet.

This app's cache svuota solo la cache temporanea di Game Tools e mostra i byte iniziali, rimossi e rimanenti. La cache delle altre app si svuota manualmente nelle impostazioni Android. La classifica delle cinque cache più grandi richiede Accesso ai dati di utilizzo e Android 8 o successivo.

Avvia le app installate identificate come giochi, apri le impostazioni del display Android e consulta la batteria. La frequenza di aggiornamento del display è in Hz, non in FPS del gioco. Ogni gioco controlla la propria grafica.

La modalità Non disturbare è facoltativa e può silenziare sveglie e contenuti multimediali, ma non rifiuta le chiamate. La barra facoltativa della frequenza richiede accesso ai dati di utilizzo e autorizzazione a comparire sopra altre app.

I risultati sono elaborati sul dispositivo. I controlli di rete richiesti contattano Cloudflare, che può ricevere il tuo IP pubblico. Nessun SDK pubblicitario o di analisi. L'interfaccia è in inglese. Le funzioni dipendono da dispositivo, versione Android e autorizzazioni.

Open game library apre l'elenco dei giochi senza svuotare cache o modificare impostazioni del dispositivo. App settings apre solo le impostazioni Android. L'app non chiude le app recenti, non arresta altre app, non modifica la grafica, non misura gli FPS dei giochi e non ne aumenta le prestazioni.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</it-IT>
~~~

~~~text
<iw-IL>
Title: Game Tools: רשת ומטמון

Short description: בדיקת השהיית TCP, ניקוי המטמון של אפליקציה זו והפעלת משחקים.

Full description:
Game Tools הוא כלי Android לבדיקת השהיית TCP, ניקוי המטמון של אפליקציה זו, קיצורי דרך למשחקים ומידע על המסך.

Network Latency מבצע חמישה חיבורי TCP אל Cloudflare בכתובת 1.1.1.1:443 ומציג השהיה ממוצעת, מינימלית ומקסימלית, תנודות וניסיונות שנכשלו. אלו זמני חיבור, לא פינג לשרת המשחק או בדיקת מהירות אינטרנט.

This app's cache מנקה רק את המטמון הזמני של Game Tools ומציג את הבתים לפני הניקוי, שנמחקו ושנותרו. מטמון של אפליקציות אחרות מנקים ידנית בהגדרות Android. דירוג חמשת המטמונים הגדולים דורש גישה לנתוני שימוש ו-Android 8 ומעלה.

הפעילו אפליקציות מותקנות שמזוהות כמשחקים, פתחו הגדרות תצוגה וצפו במצב הסוללה. קצב רענון המסך נמדד ב-Hz ולא ב-FPS של המשחק. הגרפיקה בתוך המשחק נשלטת על ידי המשחק.

מצב נא לא להפריע הוא אופציונלי ועשוי להשתיק שעונים מעוררים ומדיה, אך אינו דוחה שיחות. סרגל קצב הרענון האופציונלי דורש גישה לנתוני שימוש והרשאת הצגה מעל אפליקציות.

התוצאות מעובדות במכשיר. בדיקות רשת ביוזמתכם מתחברות ל-Cloudflare, שעשויה לקבל את כתובת ה-IP הציבורית שלכם. אין SDK לפרסום או לניתוח נתונים. הממשק באנגלית. התכונות תלויות במכשיר, בגרסת Android ובהרשאות.

Open game library פותח את רשימת המשחקים בלי לנקות מטמון או לשנות הגדרות מכשיר. App settings רק פותח את הגדרות Android. האפליקציה אינה סוגרת אפליקציות אחרונות, עוצרת אפליקציות אחרות, משנה גרפיקה, מודדת FPS במשחקים או משפרת את ביצועי המשחקים.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</iw-IL>
~~~

~~~text
<ja-JP>
Title: Game Tools: 通信・キャッシュ

Short description: TCP遅延の確認、このアプリのキャッシュ削除、ゲーム起動をひとつに。

Full description:
Game Toolsは、TCPネットワーク遅延、このアプリのキャッシュ、ゲームのショートカット、画面情報をまとめたAndroidユーティリティです。

Network LatencyはCloudflareの1.1.1.1:443へ5回のTCP接続を行い、平均・最小・最大遅延、ジッター、接続失敗を表示します。接続に要した時間を測るもので、ゲームサーバーのpingやインターネット速度テストではありません。

This app's cacheはGame Tools自身の一時キャッシュのみを削除し、削除前・削除済み・残りのバイト数を表示します。他のアプリのキャッシュはAndroid設定で手動削除します。上位5件のキャッシュ一覧には使用状況へのアクセスとAndroid 8以降が必要です。

ゲームと認識されたインストール済みアプリの起動、Android画面設定の表示、バッテリー状態の確認ができます。画面のリフレッシュレートはHzで表示し、ゲームのFPSではありません。ゲーム内の画質は各ゲームで設定します。

任意のサイレントモードはアラームやメディアも消音する場合がありますが、着信を拒否しません。任意のリフレッシュレートバーには使用状況へのアクセスと他のアプリの上への表示権限が必要です。

結果は端末上で処理されます。利用者が実行したネットワーク確認はCloudflareへ接続し、接続先に公開IPアドレスが伝わる場合があります。広告・解析SDKは含みません。アプリの表示言語は英語です。機能は端末、Androidのバージョン、権限に依存します。

Open game libraryはキャッシュ削除や端末設定の変更を行わず、ゲーム一覧を開きます。App settingsはAndroid設定を開くだけです。本アプリは、最近使ったアプリの終了、他のアプリの停止、ゲーム画質の変更、ゲームFPSの測定、ゲーム性能の向上を行いません。

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</ja-JP>
~~~

~~~text
<ko-KR>
Title: Game Tools: 네트워크·캐시

Short description: TCP 지연 시간을 확인하고 이 앱의 캐시를 정리하며 게임을 실행하세요.

Full description:
Game Tools는 TCP 네트워크 지연 시간, 이 앱의 캐시, 게임 바로가기 및 디스플레이 정보를 제공하는 Android 유틸리티입니다.

Network Latency는 Cloudflare 1.1.1.1:443에 TCP 연결을 5회 시도하고 평균·최소·최대 지연 시간, 지터와 실패 횟수를 표시합니다. 이는 연결 시간 측정이며 게임 서버 핑이나 인터넷 속도 테스트가 아닙니다.

This app's cache은 Game Tools 자체의 임시 캐시만 정리하며 정리 전, 삭제된 바이트, 남은 바이트를 표시합니다. 다른 앱의 캐시는 Android 설정에서 수동으로 정리합니다. 캐시 크기 상위 5개 목록은 사용 정보 접근 권한과 Android 8 이상이 필요합니다.

게임으로 식별된 설치 앱을 실행하고 Android 디스플레이 설정과 배터리 상태를 확인하세요. 화면 주사율은 Hz로 표시하며 게임 FPS가 아닙니다. 게임 내 그래픽은 각 게임에서 설정합니다.

선택 기능인 방해 금지 모드는 알람과 미디어를 무음으로 만들 수 있지만 전화를 거절하지는 않습니다. 선택 기능인 주사율 표시줄에는 사용 정보 접근 권한과 다른 앱 위에 표시 권한이 필요합니다.

결과는 기기에서 처리합니다. 사용자가 실행하는 네트워크 검사는 Cloudflare에 연결하며 공개 IP 주소가 전달될 수 있습니다. 광고 또는 분석 SDK는 포함하지 않습니다. 앱 인터페이스는 영어입니다. 기능은 기기, Android 버전 및 권한에 따라 달라집니다.

Open game library는 캐시를 정리하거나 기기 설정을 변경하지 않고 게임 목록을 엽니다. App settings는 Android 설정만 엽니다. 이 앱은 최근 앱을 닫거나 다른 앱을 중지하거나 게임 그래픽을 변경하거나 게임 FPS를 측정하거나 게임 성능을 향상하지 않습니다.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</ko-KR>
~~~

~~~text
<nl-NL>
Title: Game Tools: Netwerk en cache

Short description: Meet TCP-latentie, wis de cache van deze app en start je games.

Full description:
Game Tools is een Android-hulpmiddel voor TCP-netwerklatentie, de cache van deze app, gamesnelkoppelingen en scherminformatie.

Network Latency maakt vijf TCP-verbindingen met Cloudflare 1.1.1.1:443 en toont gemiddelde, minimale en maximale latentie, jitter en mislukte pogingen. Dit zijn verbindingstijden, geen ping naar gameservers of internetsnelheidstest.

This app's cache wist alleen de tijdelijke cache van Game Tools en toont de oorspronkelijke, verwijderde en resterende bytes. De cache van andere apps wis je handmatig in Android-instellingen. De lijst van vijf grootste caches vereist gebruikstoegang en Android 8 of nieuwer.

Start geïnstalleerde apps die als games worden herkend, open Android-scherminstellingen en bekijk de batterijstatus. De schermverversingssnelheid wordt gemeten in Hz, niet in game-FPS. Games beheren hun eigen grafische instellingen.

Optioneel Niet storen kan alarmen en media dempen, maar weigert geen oproepen. De optionele verversingssnelheidsbalk vereist gebruikstoegang en toestemming om over andere apps te verschijnen.

Resultaten worden op je apparaat verwerkt. Netwerkcontroles die je zelf start maken verbinding met Cloudflare, dat je openbare IP-adres kan ontvangen. Geen advertentie- of analyse-SDK's. De interface is in het Engels. Functies hangen af van apparaat, Android-versie en rechten.

Open game library opent de gamelijst zonder caches te wissen of apparaatinstellingen te wijzigen. App settings opent alleen de Android-instellingen. De app sluit geen recente apps, stopt geen andere apps, wijzigt geen gamegraphics, meet geen game-FPS en verhoogt de gameprestaties niet.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</nl-NL>
~~~

~~~text
<no-NO>
Title: Game Tools: Nettverk og cache

Short description: Mål TCP-forsinkelse, tøm denne appens hurtigbuffer og start spill.

Full description:
Game Tools er et Android-verktøy for TCP-nettverksforsinkelse, denne appens hurtigbuffer, spillsnarveier og skjerminformasjon.

Network Latency oppretter fem TCP-forbindelser til Cloudflare 1.1.1.1:443 og viser gjennomsnittlig, laveste og høyeste forsinkelse, jitter og mislykkede forsøk. Dette er tilkoblingstider, ikke ping til spillservere eller en internetthastighetstest.

This app's cache tømmer bare den midlertidige hurtigbufferen til Game Tools og viser byte før, fjernet og igjen. Hurtigbufferen til andre apper tømmes manuelt i Android-innstillingene. Listen over de fem største hurtigbufferne krever brukstilgang og Android 8 eller nyere.

Start installerte apper som gjenkjennes som spill, åpne Androids skjerminnstillinger og se batteristatus. Skjermens oppdateringsfrekvens måles i Hz, ikke spillets FPS. Spillet styrer selv grafikken.

Valgfri Ikke forstyrr kan dempe alarmer og medier, men avviser ikke anrop. Den valgfrie oppdateringslinjen krever brukstilgang og tillatelse til å vises over andre apper.

Resultater behandles på enheten. Nettverkskontroller du starter kontakter Cloudflare, som kan motta din offentlige IP-adresse. Ingen reklame- eller analyse-SDK-er. Grensesnittet er på engelsk. Funksjoner avhenger av enhet, Android-versjon og tillatelser.

Open game library åpner spillisten uten å tømme hurtiglagre eller endre enhetens innstillinger. App settings åpner bare Android-innstillinger. Appen lukker ikke nylige apper, stopper ikke andre apper, endrer ikke spillgrafikk, måler ikke spill-FPS og øker ikke spillytelsen.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</no-NO>
~~~

~~~text
<pl-PL>
Title: Game Tools: Sieć i cache

Short description: Mierz opóźnienie TCP, czyść pamięć podręczną tej aplikacji i uruchamiaj gry.

Full description:
Game Tools to narzędzie Android do pomiaru opóźnienia TCP, pamięci podręcznej tej aplikacji, skrótów do gier i informacji o ekranie.

Network Latency wykonuje pięć połączeń TCP z Cloudflare 1.1.1.1:443 i pokazuje średnie, minimalne i maksymalne opóźnienie, jitter oraz nieudane próby. To czas nawiązania połączenia, nie ping serwera gry ani test szybkości internetu.

This app's cache usuwa tylko tymczasową pamięć podręczną Game Tools i pokazuje bajty przed czyszczeniem, usunięte i pozostałe. Pamięć innych aplikacji czyści się ręcznie w ustawieniach Androida. Lista pięciu największych pamięci podręcznych wymaga dostępu do danych o użytkowaniu i Androida 8 lub nowszego.

Uruchamiaj zainstalowane aplikacje rozpoznane jako gry, otwieraj ustawienia ekranu Androida i sprawdzaj baterię. Odświeżanie ekranu jest mierzone w Hz, a nie w FPS gry. Grafiką w grze zarządza sama gra.

Opcjonalny tryb Nie przeszkadzać może wyciszać alarmy i multimedia, ale nie odrzuca połączeń. Opcjonalny pasek odświeżania wymaga dostępu do danych o użytkowaniu i zgody na wyświetlanie nad innymi aplikacjami.

Wyniki są przetwarzane na urządzeniu. Zlecane kontrole sieci łączą się z Cloudflare, który może otrzymać publiczny adres IP. Brak SDK reklamowych i analitycznych. Interfejs jest po angielsku. Funkcje zależą od urządzenia, wersji Androida i uprawnień.

Open game library otwiera listę gier bez czyszczenia pamięci podręcznej ani zmiany ustawień urządzenia. App settings tylko otwiera ustawienia Androida. Aplikacja nie zamyka ostatnich aplikacji, nie zatrzymuje innych aplikacji, nie zmienia grafiki, nie mierzy FPS gier ani nie zwiększa ich wydajności.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</pl-PL>
~~~

~~~text
<pt-BR>
Title: Game Tools: Rede e cache

Short description: Confira a latência TCP, limpe o cache deste app e abra seus jogos.

Full description:
Game Tools é um utilitário Android para latência de rede TCP, cache deste app, atalhos de jogos e informações da tela.

Network Latency faz cinco conexões TCP com Cloudflare 1.1.1.1:443 e mostra latência média, mínima e máxima, jitter e tentativas que falharam. São tempos de conexão, não ping do servidor do jogo nem teste de velocidade da Internet.

This app's cache limpa somente o cache temporário do Game Tools e mostra os bytes iniciais, removidos e restantes. O cache de outros apps é limpo manualmente nas configurações do Android. A lista dos cinco maiores caches exige acesso ao uso e Android 8 ou posterior.

Abra apps instalados identificados como jogos, acesse as configurações de tela do Android e veja a bateria. A taxa de atualização da tela é medida em Hz, não em FPS do jogo. Cada jogo controla seus próprios gráficos.

O modo Não perturbe é opcional e pode silenciar alarmes e mídia, mas não rejeita chamadas. A barra opcional de taxa de atualização exige acesso ao uso e permissão para aparecer sobre outros apps.

Os resultados são processados no dispositivo. As verificações de rede solicitadas contatam a Cloudflare, que pode receber seu IP público. Nenhum SDK de publicidade ou análise é incluído. A interface está em inglês. Os recursos dependem do dispositivo, da versão do Android e das permissões.

Open game library abre a lista de jogos sem limpar caches ou alterar configurações do dispositivo. App settings apenas abre as configurações do Android. O app não fecha apps recentes, não interrompe outros apps, não altera gráficos, não mede FPS dos jogos nem aumenta seu desempenho.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</pt-BR>
~~~

~~~text
<ro>
Title: Game Tools: Rețea și cache

Short description: Măsoară latența TCP, șterge cache-ul acestei aplicații și pornește jocuri.

Full description:
Game Tools este un utilitar Android pentru latența TCP, memoria cache a acestei aplicații, scurtături către jocuri și informații despre ecran.

Network Latency realizează cinci conexiuni TCP la Cloudflare 1.1.1.1:443 și arată latența medie, minimă și maximă, variația latenței și încercările eșuate. Sunt timpi de conectare, nu ping către serverul jocului sau test de viteză a internetului.

This app's cache șterge doar memoria cache temporară a Game Tools și arată octeții inițiali, eliminați și rămași. Cache-ul altor aplicații se șterge manual din setările Android. Lista celor mai mari cinci memorii cache necesită acces la datele de utilizare și Android 8 sau mai nou.

Pornește aplicațiile instalate identificate ca jocuri, deschide setările de afișare Android și vezi bateria. Rata de reîmprospătare a ecranului se măsoară în Hz, nu în FPS ai jocului. Grafica este controlată de fiecare joc.

Modul opțional Nu deranja poate opri sunetul alarmelor și conținutului media, dar nu respinge apeluri. Bara opțională a ratei de reîmprospătare necesită acces la utilizare și permisiunea de afișare peste alte aplicații.

Rezultatele sunt procesate pe dispozitiv. Verificările de rețea cerute contactează Cloudflare, care poate primi adresa IP publică. Fără SDK-uri de publicitate sau analiză. Interfața este în engleză. Funcțiile depind de dispozitiv, versiunea Android și permisiuni.

Open game library deschide lista jocurilor fără a curăța memoria cache sau a modifica setările dispozitivului. App settings deschide doar setările Android. Aplicația nu închide aplicațiile recente, nu oprește alte aplicații, nu modifică grafica, nu măsoară FPS-ul jocurilor și nu crește performanța acestora.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</ro>
~~~

~~~text
<ru-RU>
Title: Game Tools: Сеть и кеш

Short description: Проверяйте задержку TCP, очищайте кеш этого приложения и запускайте игры.

Full description:
Game Tools — утилита Android для проверки задержки TCP, кеша этого приложения, ярлыков игр и сведений об экране.

Network Latency выполняет пять TCP-подключений к Cloudflare 1.1.1.1:443 и показывает среднюю, минимальную и максимальную задержку, джиттер и неудачные попытки. Это время установления соединения, а не пинг игрового сервера или проверка скорости интернета.

This app's cache очищает только временный кеш Game Tools и показывает исходное, удалённое и оставшееся количество байтов. Кеш других приложений очищается вручную в настройках Android. Список пяти крупнейших кешей требует доступа к данным об использовании и Android 8 или новее.

Запускайте установленные приложения, распознанные как игры, открывайте настройки экрана Android и смотрите состояние батареи. Частота обновления экрана измеряется в Гц, а не в FPS игры. Графикой внутри игры управляет сама игра.

Необязательный режим «Не беспокоить» может отключать звук будильников и медиа, но не отклоняет звонки. Необязательная панель частоты обновления требует доступа к данным об использовании и разрешения на показ поверх приложений.

Результаты обрабатываются на устройстве. Запрошенные вами проверки сети обращаются к Cloudflare, которая может получить публичный IP-адрес. Рекламных и аналитических SDK нет. Интерфейс на английском. Функции зависят от устройства, версии Android и разрешений.

Open game library открывает список игр без очистки кэша или изменения настроек устройства. App settings только открывает настройки Android. Приложение не закрывает недавние приложения, не останавливает другие приложения, не меняет графику, не измеряет игровой FPS и не повышает производительность игр.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</ru-RU>
~~~

~~~text
<sk>
Title: Game Tools: Sieť a cache

Short description: Zmerajte latenciu TCP, vyčistite cache tejto aplikácie a spustite hry.

Full description:
Game Tools je nástroj Android na meranie latencie TCP, vyrovnávaciu pamäť tejto aplikácie, herné skratky a informácie o displeji.

Network Latency vytvorí päť TCP-pripojení ku Cloudflare 1.1.1.1:443 a zobrazí priemernú, minimálnu a maximálnu latenciu, kolísanie a neúspešné pokusy. Ide o časy pripojenia, nie ping herného servera ani test rýchlosti internetu.

This app's cache vymaže iba dočasnú vyrovnávaciu pamäť Game Tools a zobrazí pôvodné, odstránené a zostávajúce bajty. Pamäť iných aplikácií sa čistí ručne v nastaveniach Androidu. Rebríček piatich najväčších pamätí vyžaduje prístup k údajom o používaní a Android 8 alebo novší.

Spúšťajte nainštalované aplikácie rozpoznané ako hry, otvorte nastavenia displeja Androidu a zobrazte stav batérie. Obnovovacia frekvencia displeja je v Hz, nie FPS hry. Grafiku v hre nastavuje samotná hra.

Voliteľný režim Nerušiť môže stíšiť budíky a médiá, ale neodmieta hovory. Voliteľný panel frekvencie vyžaduje prístup k údajom o používaní a povolenie zobrazovať nad inými aplikáciami.

Výsledky sa spracúvajú v zariadení. Sieťové kontroly na váš pokyn kontaktujú Cloudflare, ktorý môže získať vašu verejnú IP adresu. Bez reklamných a analytických SDK. Rozhranie je v angličtine. Funkcie závisia od zariadenia, verzie Androidu a povolení.

Open game library otvorí zoznam hier bez čistenia vyrovnávacej pamäte alebo zmeny nastavení zariadenia. App settings len otvorí nastavenia Androidu. Aplikácia nezatvára nedávne aplikácie, nezastavuje iné aplikácie, nemení grafiku hier, nemeria herné FPS ani nezvyšuje herný výkon.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</sk>
~~~

~~~text
<sv-SE>
Title: Game Tools: Nätverk och cache

Short description: Mät TCP-latens, rensa den här appens cache och starta dina spel.

Full description:
Game Tools är ett Android-verktyg för TCP-nätverkslatens, den här appens cache, spelgenvägar och skärminformation.

Network Latency gör fem TCP-anslutningar till Cloudflare 1.1.1.1:443 och visar genomsnittlig, lägsta och högsta latens, jitter och misslyckade försök. Det är anslutningstider, inte ping till spelservrar eller ett test av internethastighet.

This app's cache rensar bara Game Tools tillfälliga cache och visar byte före, borttagna och kvarvarande. Andra appars cache rensas manuellt i Android-inställningarna. Listan med de fem största cacharna kräver åtkomst till användningsdata och Android 8 eller senare.

Starta installerade appar som identifieras som spel, öppna Androids skärminställningar och se batteristatus. Skärmens uppdateringsfrekvens mäts i Hz, inte spelets FPS. Spelen styr sina egna grafikinställningar.

Valfritt Stör ej kan tysta alarm och media men avvisar inte samtal. Den valfria uppdateringsfrekvensraden kräver åtkomst till användningsdata och tillstånd att visas över andra appar.

Resultaten behandlas på din enhet. Nätverkskontroller som du startar kontaktar Cloudflare, som kan få din offentliga IP-adress. Inga reklam- eller analys-SDK:er ingår. Gränssnittet är på engelska. Funktioner beror på enhet, Android-version och behörigheter.

Open game library öppnar spellistan utan att rensa cache eller ändra enhetens inställningar. App settings öppnar bara Android-inställningar. Appen stänger inte senaste appar, stoppar inte andra appar, ändrar inte spelgrafik, mäter inte spel-FPS och ökar inte spelprestandan.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</sv-SE>
~~~

~~~text
<th>
Title: Game Tools: เครือข่ายและแคช

Short description: ตรวจสอบเวลาแฝง TCP ล้างแคชของแอปนี้ และเปิดเกมของคุณ

Full description:
Game Tools เป็นเครื่องมือ Android สำหรับเวลาแฝงเครือข่าย TCP แคชของแอปนี้ ทางลัดเกม และข้อมูลหน้าจอ

Network Latency เชื่อมต่อ TCP ไปยัง Cloudflare 1.1.1.1:443 จำนวนห้าครั้ง และแสดงเวลาแฝงเฉลี่ย ต่ำสุด สูงสุด ค่า jitter และครั้งที่ไม่สำเร็จ ผลคือเวลาในการเชื่อมต่อ ไม่ใช่ ping ของเซิร์ฟเวอร์เกมหรือการทดสอบความเร็วอินเทอร์เน็ต

This app's cache ล้างเฉพาะแคชชั่วคราวของ Game Tools และแสดงจำนวนไบต์ก่อนล้าง ที่ลบ และที่เหลือ แคชของแอปอื่นต้องล้างเองในการตั้งค่า Android รายการแคชที่ใหญ่ที่สุดห้าอันดับต้องใช้สิทธิ์เข้าถึงข้อมูลการใช้งานและ Android 8 ขึ้นไป

เปิดแอปที่ติดตั้งซึ่งระบบระบุว่าเป็นเกม เปิดการตั้งค่าหน้าจอ Android และดูสถานะแบตเตอรี่ อัตรารีเฟรชหน้าจอแสดงเป็น Hz ไม่ใช่ FPS ของเกม กราฟิกภายในเกมยังควบคุมโดยเกมนั้น

โหมดห้ามรบกวนเป็นตัวเลือกและอาจปิดเสียงนาฬิกาปลุกกับสื่อ แต่ไม่ปฏิเสธสายเรียกเข้า แถบอัตรารีเฟรชเสริมต้องมีสิทธิ์เข้าถึงข้อมูลการใช้งานและแสดงทับแอปอื่น

ผลประมวลผลบนอุปกรณ์ การตรวจสอบเครือข่ายที่คุณสั่งจะติดต่อ Cloudflare ซึ่งอาจได้รับ IP สาธารณะของคุณ ไม่มี SDK โฆษณาหรือวิเคราะห์ข้อมูล อินเทอร์เฟซเป็นภาษาอังกฤษ ฟังก์ชันขึ้นอยู่กับอุปกรณ์ เวอร์ชัน Android และสิทธิ์ที่อนุญาต

Open game library เปิดรายการเกมโดยไม่ล้างแคชหรือเปลี่ยนการตั้งค่าอุปกรณ์ App settings เปิดการตั้งค่า Android เท่านั้น แอปนี้ไม่ปิดแอปล่าสุด ไม่หยุดแอปอื่น ไม่เปลี่ยนกราฟิกเกม ไม่วัด FPS ของเกม และไม่เพิ่มประสิทธิภาพเกม

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</th>
~~~

~~~text
<tr-TR>
Title: Game Tools: Ağ ve önbellek

Short description: TCP gecikmesini ölçün, bu uygulamanın önbelleğini temizleyin ve oyun açın.

Full description:
Game Tools; TCP ağ gecikmesi, bu uygulamanın önbelleği, oyun kısayolları ve ekran bilgileri için bir Android aracıdır.

Network Latency, Cloudflare 1.1.1.1:443 adresine beş TCP bağlantısı kurar; ortalama, en düşük ve en yüksek gecikmeyi, jitter değerini ve başarısız denemeleri gösterir. Bunlar bağlantı süreleridir; oyun sunucusu pingi veya İnternet hız testi değildir.

This app's cache yalnızca Game Tools'un geçici önbelleğini temizler; önceki, silinen ve kalan baytları gösterir. Diğer uygulamaların önbelleği Android ayarlarında elle temizlenir. En büyük beş önbellek listesi için kullanım erişimi ve Android 8 veya sonrası gerekir.

Oyun olarak tanınan yüklü uygulamaları başlatın, Android ekran ayarlarını açın ve pil durumunu görüntüleyin. Ekran yenileme hızı Hz cinsindedir, oyun FPS'si değildir. Oyun içi grafikleri oyunun kendisi kontrol eder.

İsteğe bağlı Rahatsız Etmeyin, alarmları ve medyayı sessize alabilir ancak aramaları reddetmez. İsteğe bağlı yenileme hızı çubuğu için kullanım erişimi ve diğer uygulamalar üzerinde gösterme izni gerekir.

Sonuçlar cihazda işlenir. Başlattığınız ağ kontrolleri Cloudflare ile bağlantı kurar; Cloudflare genel IP adresinizi alabilir. Reklam veya analiz SDK'sı yoktur. Arayüz İngilizcedir. Özellikler cihaza, Android sürümüne ve izinlere bağlıdır.

Open game library, önbellekleri temizlemeden veya cihaz ayarlarını değiştirmeden oyun listesini açar. App settings yalnızca Android ayarlarını açar. Uygulama son uygulamaları kapatmaz, diğer uygulamaları durdurmaz, oyun grafiklerini değiştirmez, oyun FPS değerini ölçmez veya oyun performansını artırmaz.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</tr-TR>
~~~

~~~text
<uk>
Title: Game Tools: Мережа й кеш

Short description: Перевіряйте затримку TCP, очищайте кеш цієї програми й запускайте ігри.

Full description:
Game Tools — утиліта Android для перевірки затримки TCP, кешу цієї програми, ярликів ігор і відомостей про екран.

Network Latency виконує п'ять TCP-підключень до Cloudflare 1.1.1.1:443 та показує середню, мінімальну й максимальну затримку, джитер і невдалі спроби. Це час встановлення з'єднання, а не пінг ігрового сервера чи тест швидкості інтернету.

This app's cache очищає лише тимчасовий кеш Game Tools і показує початкові, видалені та залишені байти. Кеш інших програм очищається вручну в налаштуваннях Android. Список п'яти найбільших кешів потребує доступу до даних використання та Android 8 або новішого.

Запускайте встановлені програми, розпізнані як ігри, відкривайте налаштування екрана Android і переглядайте стан батареї. Частота оновлення екрана вимірюється в Гц, а не у FPS гри. Графікою всередині гри керує сама гра.

Необов'язковий режим «Не турбувати» може вимикати звук будильників і медіа, але не відхиляє дзвінки. Необов'язкова панель частоти оновлення потребує доступу до даних використання та дозволу показу поверх інших програм.

Результати обробляються на пристрої. Замовлені вами перевірки мережі звертаються до Cloudflare, яка може отримати публічну IP-адресу. Рекламних і аналітичних SDK немає. Інтерфейс англійською. Функції залежать від пристрою, версії Android і дозволів.

Open game library відкриває список ігор без очищення кешу або зміни налаштувань пристрою. App settings лише відкриває налаштування Android. Програма не закриває нещодавні програми, не зупиняє інші програми, не змінює графіку, не вимірює ігровий FPS і не підвищує продуктивність ігор.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</uk>
~~~

~~~text
<vi>
Title: Game Tools: Mạng và cache

Short description: Đo độ trễ TCP, xóa bộ nhớ đệm của ứng dụng này và mở trò chơi.

Full description:
Game Tools là tiện ích Android cho độ trễ mạng TCP, bộ nhớ đệm của ứng dụng này, lối tắt trò chơi và thông tin màn hình.

Network Latency thực hiện năm kết nối TCP tới Cloudflare 1.1.1.1:443, hiển thị độ trễ trung bình, thấp nhất, cao nhất, độ dao động và các lần thử thất bại. Đây là thời gian kết nối, không phải ping máy chủ trò chơi hay bài kiểm tra tốc độ Internet.

This app's cache chỉ xóa bộ nhớ đệm tạm thời của Game Tools và hiển thị số byte ban đầu, đã xóa và còn lại. Bộ nhớ đệm của ứng dụng khác được xóa thủ công trong cài đặt Android. Danh sách năm bộ nhớ đệm lớn nhất cần quyền truy cập dữ liệu sử dụng và Android 8 trở lên.

Mở ứng dụng đã cài được nhận diện là trò chơi, mở cài đặt màn hình Android và xem pin. Tần số quét màn hình được đo bằng Hz, không phải FPS của trò chơi. Đồ họa trong trò chơi do chính trò chơi kiểm soát.

Chế độ Không làm phiền là tùy chọn, có thể tắt tiếng báo thức và nội dung nghe nhìn nhưng không từ chối cuộc gọi. Thanh tần số quét tùy chọn cần quyền truy cập dữ liệu sử dụng và hiển thị trên ứng dụng khác.

Kết quả được xử lý trên thiết bị. Kiểm tra mạng do bạn yêu cầu liên hệ Cloudflare, nơi có thể nhận địa chỉ IP công khai của bạn. Không có SDK quảng cáo hoặc phân tích. Giao diện bằng tiếng Anh. Tính năng phụ thuộc thiết bị, phiên bản Android và quyền được cấp.

Open game library mở danh sách trò chơi mà không dọn bộ nhớ đệm hoặc thay đổi cài đặt thiết bị. App settings chỉ mở cài đặt Android. Ứng dụng không đóng ứng dụng gần đây, không dừng ứng dụng khác, không thay đổi đồ họa, không đo FPS trò chơi và không tăng hiệu năng trò chơi.

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</vi>
~~~

~~~text
<zh-CN>
Title: Game Tools：网络与缓存

Short description: 查看 TCP 延迟、清理本应用缓存并启动游戏。

Full description:
Game Tools 是一款 Android 实用工具，提供 TCP 网络延迟检测、本应用缓存清理、游戏快捷入口和屏幕信息。

Network Latency 向 Cloudflare 1.1.1.1:443 发起五次 TCP 连接，显示平均、最低和最高延迟、抖动及失败次数。测量的是建立连接所需的时间，并非游戏服务器 ping 或互联网速度测试。

This app's cache 仅清理 Game Tools 自身的临时缓存，显示清理前、已删除和剩余的字节数。其他应用的缓存需在 Android 设置中手动清理。查看缓存最大的五个应用需要使用情况访问权限及 Android 8 或更高版本。

启动被识别为游戏的已安装应用、打开 Android 显示设置并查看电池状态。屏幕刷新率以 Hz 为单位，并非游戏 FPS。游戏内的画质设置由各游戏自行控制。

可选的勿扰模式可能会静音闹钟和媒体，但不会拒接来电。可选的刷新率显示条需要使用情况访问权限及在其他应用上层显示的权限。

结果在设备上处理。用户主动执行的网络检测会连接 Cloudflare，对方可能接收到您的公网 IP 地址。不包含广告或分析 SDK。应用界面为英语。功能取决于设备、Android 版本及已授予的权限。

Open game library仅打开游戏列表，不会清理缓存或更改设备设置。App settings仅打开Android设置。本应用不会关闭最近使用的应用、停止其他应用、更改游戏画质、测量游戏FPS或提升游戏性能。

PT Deploy Dulu Pulang Nanti
Support: seandyadryan2@gmail.com
</zh-CN>
~~~
